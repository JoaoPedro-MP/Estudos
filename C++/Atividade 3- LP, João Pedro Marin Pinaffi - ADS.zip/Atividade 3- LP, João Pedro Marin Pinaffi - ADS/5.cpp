#include <stdio.h>
int main() {
int score = 5;
printf("%d\n", 5 + 10 * 5 % 6);
printf("%d\n", 10 / 4);
printf("%f\n", 10.0 / 4.0);
printf("%c\n", 'A' + 1);
printf("%d\n", score + (score == 0));
}