#include <math.h>
#include <stdio.h>
#include <stdlib.h>
int main()
{
    int Resultado=0, N1=0, N2=0;
    printf("Digite o primeiro numero: ");
    scanf("%d", &N1);
    printf("Digite o segundo numero: ");
    scanf("%d", &N2);

    Resultado=N1+N2;

    printf("O resultado é: %d", Resultado);
    

    
}